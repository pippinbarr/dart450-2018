/*

Blast.js template
Pippin Barr


*/

$(document).ready(function() {


});
