/**********************************************

DART 450, Winter 2018
The Grid
Pippin Barr

Adds a grid of divs to the page

**********************************************/

$(document).ready(function () {

  var $div1 = $('<div></div>');
  $('body').append($div1);

  var $div2 = $('<div></div>');
  $('body').append($div2);

  var $div3 = $('<div></div>');
  $('body').append($div3);

  var $div4 = $('<div></div>');
  $('body').append($div4);

  var $div5 = $('<div></div>');
  $('body').append($div5);

  var $div6 = $('<div></div>');
  $('body').append($div6);

  var $div7 = $('<div></div>');
  $('body').append($div7);

  // This is tedious!

});
